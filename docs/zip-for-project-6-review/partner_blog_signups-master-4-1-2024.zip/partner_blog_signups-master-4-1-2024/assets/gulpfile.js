var gulp = require('gulp');
var sass = require('gulp-sass');

// gulp.task('styles', function() {
//     gulp.src('assets/scss/**/*.scss')
//         .pipe(sass().on('error', sass.logError))
//         .pipe(gulp.dest('./css/'))
// });

// //Watch task
// gulp.task('default',function() {
//     gulp.watch('scss/**/*.scss',['styles']);
// });



// Define tasks after requiring dependencies
function style() {
  // Where should gulp look for the sass files?
  // My .sass files are stored in the styles folder
  // (If you want to use scss files, simply look for *.scss files instead)
  return (
    gulp
      .src("scss/**/*.scss")
      // Initialize sourcemaps before compilation starts

      // .pipe(sourcemaps.init())

      // Use sass with the files found, and log any errors
      .pipe(sass())
      .on("error", sass.logError)
      // Use postcss with autoprefixer and compress the compiled file using cssnano

      // .pipe(postcss([autoprefixer(), cssnano()]))
      // // Now add/write the sourcemaps
      // .pipe(sourcemaps.write())

      // What is the destination for the compiled file?
      .pipe(gulp.dest("css"))
  );
}

// Expose the task by exporting it
// This allows you to run it from the commandline using
// $ gulp style
exports.style = style;


function watch() {
  // gulp.watch takes in the location of the files to watch for changes
  // and the name of the function we want to run on change
  gulp.watch('scss/**/*.scss', style)
  // browserSync.init({
  //     server: {
  //         baseDir: "./"
  //     },
  //     injectChanges: true,
  //     watch: true
  // });
}

// Don't forget to expose the task!
exports.watch = watch;





// var bower = require('gulp-bower'),
//     include = require('gulp-include'),
//     gulp = require('gulp'),
//     gutil = require('gulp-util'),
//     jshint = require('gulp-jshint'),
//     rename = require('gulp-rename'),
//     sass = require('gulp-sass'),
//     sourcemaps = require('gulp-sourcemaps'),
//     uglify = require('gulp-uglify'),
//     watch = require('gulp-watch');

// var config = {
//    bowerDir: './bower_components' 
// }

// gulp.task('bower', function(){
//   return bower();
// });

// //Move FA icon fonts
// gulp.task('icons', ['bower'], function() { 
//   return gulp.src(config.bowerDir + '/fontawesome/fonts/**.*') 
//     .pipe(gulp.dest('./fonts')); 
// });

// //Initialize project
  // gulp.task('init', ['icons']);

  // //Compile and minify stlyes
  // gulp.task('styles', function() {
  //   return gulp.src('./scss/*.scss')
  //     .pipe(rename({suffix: '.min'}))
  //     .pipe(sourcemaps.init())
  //     .pipe(sass({outputStyle:'compressed'}).on('error', sass.logError))
  //     .pipe(sourcemaps.write())
  //     .pipe(gulp.dest('./css'));
  // });
  
  // gulp.task('scripts', function() {
  //   return gulp.src('./js/*.js')
  //     .pipe(include())
  //     .pipe(jshint())
  //     .pipe(jshint.reporter('jshint-stylish'))
  //     .pipe(uglify())
  //     .pipe(rename('main.min.js'))
  //     .pipe(gulp.dest('./js/min'));
  // });
  
// //Watch for changes
// gulp.task('watch', function() {
//   gulp.watch('./scss/*.scss', ['styles']);
//   gulp.watch('./js/*.js', ['scripts']);
// });

// //Default gulp function
// gulp.task('default', ['watch'], function() {

// });
