(function ($) {
	var pop_button_after_submit;

	$(".contains-pemail")
		.has(
			".flipbook_form, .alternate_nonsubscriber_form, .promoting_book_launch_form"
		)
		.addClass("no-bg");

	//URL param function
	var qs = (function (a) {
		if (a === "") return {};
		var b = {};
		for (var i = 0; i < a.length; ++i) {
			var p = a[i].split("=");

			if (p.length != 2) continue;
			b[p[0]] = decodeURIComponent(p[1].replace(/\+/g, " "));
		}
		return b;
	})(window.location.search.substr(1).split("&"));

	//Function to get specific cookie value (returns str)
	function getCookieVal(name) {
		var value = "; " + document.cookie;
		var parts = value.split("; " + name + "=");
		if (parts.length == 2) return parts.pop().split(";").shift();
	}

	//Expire a specific cookie
	function expireCookie(name) {
		document.cookie =
			name + "=;expires=Thu, 01 Jan 1980 00:00:01 GMT; path=/";
	}

	//Create PBSdismissCookie cookie to not show popup until cookies are cleared (or until the year 10000)
	function writeDismissCookie() {
		document.cookie =
			"PBSdismissCookie=true; expires=Fri, 31 Dec 9999 23:59:59 GMT; path=/";
	}

	//Create PBSsignupCookie cookie to not show popup until cookies are cleared (or until the year 10000)
	function writeSignupCookie() {
		document.cookie =
			"PBSsignupCookie=true; expires=Fri, 31 Dec 9999 23:59:59 GMT; path=/";
	}

	//Cookie that tracks if popup was viewed and how many times
	function writeViewCookie() {
		if (getCookieVal("PBSpageViewCookie") === undefined) {
			//Set cookie and expire after 14 days
			var currDate = new Date();
			var expDate = new Date(
				currDate.getFullYear(),
				currDate.getMonth(),
				currDate.getDate() + 14
			);
			document.cookie =
				"PBSpageViewCookie=0, expireDate=" +
				expDate.toUTCString() +
				"; expires=" +
				expDate.toUTCString() +
				"; path=/";
		} else {
			var expireDate = document.cookie.split("expireDate=")[1];
			var viewCount = parseInt(getCookieVal("PBSpageViewCookie"));
			if (viewCount === 19) {
				//Expire cookie after 20 page views
				expireCookie("PBSpageViewCookie");
			} else {
				//Iterate over cookie value, keep same expiry date
				var viewInt = viewCount + 1;
				document.cookie =
					"PBSpageViewCookie=" +
					viewInt +
					", expireDate=" +
					expireDate +
					"; expires=" +
					expireDate +
					"; path=/";
			}
		}
	}

	//Function to validate an email address
	function validateEmail(uEmail) {
		var filter = /^(([\w-\.]|([-]|[_]|[.]|[+]))+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
		if (filter.test(uEmail)) {
			return true;
		} else {
			return false;
		}
	}

	//Function to show popup
	function showPopup() {
		$("#pbs-popup-form-div").fadeIn();
	}

	$(document).ready(function () {
		var pluginDir = WPURLS.plugins_url;

		//Iterate page view cookie
		if ($("#pbs-popup-form-div").length > 0) {
			writeViewCookie();
		} else {
			if (getCookieVal("PBSpageViewCookie") !== undefined) {
				writeViewCookie();
			}
		}

		if ($("#pbs-popup-form-div").length > 0) {
			//Add icons to popup form
			$("#pbs-popup-form-div .partner-form-container").prepend(
				'<i class="fa fa-times"></i>'
			);
			$(
				"#pbs-popup-form-div .partner-form-container .input-wrap .email-input"
			).before('<i class="fa fa-envelope-o"></i>');
			$(
				"#pbs-popup-form-div .partner-form-container .input-wrap select"
			).after('<i class="select-arrows"></i>');
			$(
				"#pbs-popup-form-div .partner-form-container .input-wrap .email-input"
			).on("focus", function () {
				$("#pbs-popup-form-div .input-wrap.select").css(
					"display",
					"block"
				);
			});

			//Dismiss popup on click ('x' or clicking on background)
			$("#pbs-popup-form-div").on("click", function (e) {
				if (
					$("form.partner-form").has(e.target).length > 0 ||
					$(".bb-cta-form-container form").has(e.target).length > 0
				) {
					return;
				}
				$("#pbs-popup-form-div").fadeOut();
			});

			$(".bb-cta-form-container a.dismiss").on("click", function (e) {
				e.preventDefault();
			});

			$(".form-bottom a.dismiss, .doc_share a.dismiss").on(
				"click",
				function (e) {
					e.preventDefault();
					writeDismissCookie();
					$("#pbs-popup-form-div").fadeOut();
				}
			);

			//Show popup after 15 seconds if not previously dismissed and page view count > 20 or not viewed in the last 14 days
			if (
				getCookieVal("PBSdismissCookie") === undefined &&
				parseInt(getCookieVal("PBSpageViewCookie")) === 0 &&
				$(".doc_share_button").length === 0 &&
				$.trim($("#pbs-popup-form-div").html()) !== ""
			) {
				setTimeout(showPopup, 30000);
			}

			// if there is a doc share button, populate the content from the data attr's on the button element.
			if ($(".doc_share_button").length > 0) {
				$(".doc_share_button").on("click", function (e) {
					window.sharedDocHref = $(this).data("href");
					var pop_heading = $(this).data("heading");
					var pop_content = $(this).data("content");
					var pop_button = $(this).data("button");
					pop_button_after_submit = $(this).data(
						"button-after-submit"
					);
					var pop_img = $(this).data("img");
					var conversionType = $(this).data("conversion-type");

					// get the first cta to replace its content
					var first_cta = $(
						"#pbs-popup-form-div .bb-cta-form-container:first-child"
					);
					// hide any remaining ctas
					$(
						"#pbs-popup-form-div .bb-cta-form-container:not(:first-child)"
					).hide();

					first_cta.find("a.dismiss").css("display", "none");
					if (pop_heading !== undefined) {
						first_cta
							.find(".form-top .form-title")
							.text(pop_heading);
					}
					if (pop_content !== undefined) {
						first_cta.find(".form-middle p").text(pop_content);
					}
					if (pop_img !== undefined) {
						first_cta.find(".form-middle img").attr("src", pop_img);
					}
					if (conversionType !== undefined) {
						first_cta
							.find("#conversion-type")
							.attr("value", conversionType);
						console.log("conversion type set: " + conversionType);
					}
					if (pop_button !== undefined) {
						first_cta.find(".form-bottom button").text(pop_button);
					}

					e.preventDefault();

					if (
						getCookieVal("user_signed_up") === undefined &&
						getCookieVal("PBSsignupCookie") === undefined
					) {
						showPopup();
						$("#pbs-popup-form-div").addClass("doc_share");
					}
					if (
						getCookieVal("PBSsignupCookie") !== undefined ||
						getCookieVal("user_signed_up") !== undefined ||
						getCookieVal("subscribed_to_partner_blog") !== undefined
					) {
						window.open(sharedDocHref);
					}

					// if tablet-ish or less open PDF
					if ($(window).width() < 767) {
						window.open(sharedDocHref);
					}
				});
			}
		}

		//Change link for Author Claim CTAs
		if ($(".author-claim-container").length > 0) {
			$("#pbs-side-context .author-claim-container a.claim-link").attr(
				"href",
				"https://partners.bookbub.com/authors?pd_source=pblog_dcta_author-profiles&utm_source=pblog_dcta_author-profiles&utm_medium=referral"
			);
			$("#pbs-bottom-form-div .author-claim-container a.claim-link").attr(
				"href",
				"https://partners.bookbub.com/authors?pd_source=pblog_dcta_author-profiles&utm_source=pblog_dcta_author-profiles&utm_medium=referral"
			);
			$("#pbs-popup-form-div .author-claim-container a.claim-link").attr(
				"href",
				"https://partners.bookbub.com/authors?pd_source=pblog_dcta_author-profiles&utm_source=pblog_dcta_author-profiles&utm_medium=referral"
			);
		}

		//Change link for Preorder CTAs
		if ($(".preorder-alert-container").length > 0) {
			$("#pbs-side-context .preorder-alert-container a.claim-link").attr(
				"href",
				"https://partners.bookbub.com/preorder_promotions/new?pd_source=pblog_dcta_preorder-alerts&utm_source=pblog_dcta_preorder-alerts&utm_medium=referral"
			);
			$(
				"#pbs-bottom-form-div .preorder-alert-container a.claim-link"
			).attr(
				"href",
				"https://partners.bookbub.com/preorder_promotions/new?pd_source=pblog_dcta_preorder-alerts&utm_source=pblog_dcta_preorder-alerts&utm_medium=referral"
			);
			$(
				"#pbs-popup-form-div .preorder-alert-container a.claim-link"
			).attr(
				"href",
				"https://partners.bookbub.com/preorder_promotions/new?pd_source=pblog_dcta_preorder-alerts&utm_source=pblog_dcta_preorder-alerts&utm_medium=referral"
			);
		}

		//Ads Beta AJAX
		if ($("form.bb-ads-form").length > 0) {
			if (
				$("#bb-ads-beta-inject").length > 0 &&
				$("#pbs-bottom-form-div form.bb-ads-form").length > 0
			) {
				$("#pbs-bottom-form-div").appendTo("#bb-ads-beta-inject");
				$(".author-box").css("margin-top", "30px");
				$("#pbs-bottom-form-div").css({
					"margin-top": "0",
					"margin-bottom": "0",
				});
			}

			var bbAdsFormSubmit = function ($context) {
				var $form = $context;
				var $resp = $form.find(".resp-msg");
				var $email = $form.find("input.email-input").val();
				var $role = $form.find("select.role-input").val();
				var $button = $form.find("button.partner-email-submit");
				var $buttonOrig = $button.html();
				var cleanEmail = encodeURIComponent($email);
				var containerID = $form.closest("[id]").attr("id");

				if (containerID == "pbs-side-context") {
					$form
						.find('input[name="source"]')
						.val("pblog_dcta_ads-beta_mod");
				} else if (containerID == "pbs-bottom-form-div") {
					$form
						.find('input[name="source"]')
						.val("pblog_dcta_ads-beta_post");
				} else if (containerID == "pbs-popup-form-div") {
					$form
						.find('input[name="source"]')
						.val("pblog_dcta_ads-beta_pop");
				}

				$resp.fadeOut();
				$form.find(".err-msg").remove();

				if (validateEmail($email) === true && $role !== "empty") {
					$button.addClass("loading");
					$button.html(
						'<img class="loader" src="' +
							pluginDir +
							'/assets/images/loading.gif" alt="loading"/>'
					);

					$.ajax({
						method: "POST",
						url:
							"https://www.bookbub.com/ad_unit_updates_subscription/create",
						data: $form.serialize(),
						crossDomain: true,
						xhrFields: { withCredentials: true },
						success: function (data, textStatus, jqXHR) {
							if ($role && $role.indexOf("Author") !== -1) {
								document.cookie =
									"partner_type=Author; expires=Fri, 31 Dec 9999 23:59:59 GMT; path=/";
							}
							document.cookie =
								"subscribed_to_ads_beta_group=true; expires=Fri, 31 Dec 9999 23:59:59 GMT; path=/";
							$button.removeClass("loading");
							$button
								.html($buttonOrig)
								.find("img.loader")
								.remove();
							window.location.href =
								"https://insights.bookbub.com/bookbub-ads-beta-additional-information/?email=" +
								cleanEmail;
						},
						error: function (jqXHR, textStatus, errorThrown) {
							$button.removeClass("loading");
							$button
								.html($buttonOrig)
								.find("img.loader")
								.remove();
							$resp
								.text(
									"We are unable to process your request at this time."
								)
								.addClass("error")
								.fadeIn();
						},
					});
				} else {
					//Error message for email field
					if (validateEmail($email) === false) {
						$form
							.find("input.email-input")
							.addClass("error")
							.parent()
							.after(
								'<div class="err-msg">Please enter a valid email address.</div>'
							);
					}
					//Error message for role selector
					if ($role == "empty") {
						$form
							.find("select.role-input")
							.addClass("error")
							.parent()
							.after(
								'<div class="err-msg">Please select a role.</div>'
							);
					}
				}
			}; // bbAdsFormSubmit

			var bbAdsFormSubmitDebounced = _.debounce(bbAdsFormSubmit, 1000);

			$("form.bb-ads-form").on("submit", function (e) {
				e.preventDefault();
				var $context = $(this);
				bbAdsFormSubmitDebounced($context);
			});
		}

		var scrapedEmail = qs.email;

		//Ads Beta form 2
		if ($("form.bb-ads-form-part2").length > 0) {
			$('form.bb-ads-form-part2 input[name="emailAddress"]').val(
				scrapedEmail
			);

			$("form.bb-ads-form-part2").on("submit", function (e) {
				e.preventDefault();

				var $form = $(this);
				var $resp = $form.find(".resp-msg");
				var $button = $form.find("button.partner-email-submit");
				var $buttonOrig = $button.html();

				$resp.fadeOut();
				$form.find(".err-msg").remove();

				$button.addClass("loading");
				$button.html(
					'<img class="loader" src="' +
						pluginDir +
						'/assets/images/loading.gif" alt="loading"/>'
				);

				$.ajax({
					method: "POST",
					url: "https://www.bookbub.com/survey_submission/create",
					data: $form.serialize(),
					crossDomain: true,
					xhrFields: { withCredentials: true },
					success: function (data, textStatus, jqXHR) {
						$button.removeClass("loading");
						$button.html($buttonOrig).find("img.loader").remove();
						$form.find(".form-bottom").remove();
						$form.find(".field-wrap").remove();
						$("body").animate({ scrollTop: 0 }, "slow");
						$resp
							.html(
								'Thank you for your interest in BookBub Ads! Your name has been added to our waitlist. You can expect to receive an email from us as we start opening the platform to more advertisers in the months ahead. In the meantime, feel free to check out our <a href="http://support.bookbub.com/" target="_blank">FAQs</a> if you have any questions or would like to learn more about Ads.'
							)
							.addClass("success")
							.fadeIn();
					},
					error: function (jqXHR, textStatus, errorThrown) {
						$button.removeClass("loading");
						$button.html($buttonOrig).find("img.loader").remove();
						$resp
							.text(
								"We are unable to process your request at this time."
							)
							.addClass("error")
							.fadeIn();
					},
				});
			});
		}

		//Ads Follow Up Survey
		if ($("form.ads_follow_up_survey").length > 0) {
			$('form.ads_follow_up_survey input[name="emailAddress"]').val(
				scrapedEmail
			);

			$("form.ads_follow_up_survey").on("submit", function (e) {
				e.preventDefault();

				var $form = $(this);
				var $resp = $form.find(".resp-msg");
				var $button = $form.find("button.partner-email-submit");
				var $buttonOrig = $button.html();

				$resp.fadeOut();
				$form.find(".err-msg").remove();

				$button.addClass("loading");
				$button.html(
					'<img class="loader" src="' +
						pluginDir +
						'/assets/images/loading.gif" alt="loading"/>'
				);

				$.ajax({
					method: "POST",
					url: "https://www.bookbub.com/survey_submission/create",
					data: $form.serialize(),
					crossDomain: true,
					xhrFields: { withCredentials: true },
					success: function (data, textStatus, jqXHR) {
						$button.removeClass("loading");
						$button.html($buttonOrig).find("img.loader").remove();
						$form.find(".form-bottom").remove();
						$form.find(".field-wrap").remove();
						$("body").animate({ scrollTop: 0 }, "slow");
						$resp
							.html(
								"Thanks so much for your feedback! As a reminder you can contact our team at any time to ask questions about your ad campaigns or review the resources in our Ultimate Guide to BookBub Ads for tips, guidance, and strategies."
							)
							.addClass("success")
							.fadeIn();
					},
					error: function (jqXHR, textStatus, errorThrown) {
						$button.removeClass("loading");
						$button.html($buttonOrig).find("img.loader").remove();
						$resp
							.text(
								"We are unable to process your request at this time."
							)
							.addClass("error")
							.fadeIn();
					},
				});
			});
		}

		//AJAX for form submits
		if (
			$("form.partner-form").length > 0 ||
			$("form.bb-flipbook-form").length > 0
		) {
			var bbFlipbookFormSubmit = function ($context) {
				var $form = $context;
				var $resp = $form.find(".resp-msg");
				var $email = $form.find("input.email-input").val();
				var $role = $form.find("select.role-input").val();
				var $button = $form.find("button.partner-email-submit");
				var $buttonOrig = $button.html();
				var containerID = $form.closest("[id]").attr("id");
				var gaEventLabel = null;

				if (containerID == "pbs-side-form-div") {
					gaEventLabel = "sidebar form";
				} else if (containerID == "pbs-bottom-form-div") {
					gaEventLabel = "bottom form";
				} else if (containerID == "pbs-popup-form-div") {
					gaEventLabel = "popup form";
				} else if (containerID == "pbs-inline-form-div") {
					gaEventLabel = "inline form";
				}

				$resp.fadeOut();
				$form.find(".err-msg").remove();

				if (validateEmail($email) === true && $role !== "empty") {
					$button.addClass("loading");
					$button.html(
						'<img class="loader" src="' +
							pluginDir +
							'/assets/images/loading.gif" alt="loading"/>'
					);

					$.ajax({
						method: "POST",
						url:
							"https://www.bookbub.com/partner_blog_subscription/create",
						data: $form.serialize(),
						crossDomain: true,
						xhrFields: { withCredentials: true },
						success: function (data, textStatus, jqXHR) {
							if ($role && $role.indexOf("Author") !== -1) {
								document.cookie =
									"partner_type=Author; expires=Fri, 31 Dec 9999 23:59:59 GMT; path=/";
							}
							document.cookie =
								"subscribed_to_partner_blog=true; expires=Fri, 31 Dec 9999 23:59:59 GMT; path=/";
							$button.removeClass("loading");
							$button
								.html($buttonOrig)
								.find("img.loader")
								.remove();
							if (jqXHR.status === 201) {
								$resp
									.text("Thank you for subscribing!")
									.removeClass("notice error")
									.addClass("success")
									.fadeIn();

								// change button text
								$(
									"#pbs-popup-form-div.doc_share .form-bottom button"
								).text(pop_button_after_submit);

								$form.find(".input-wrap").fadeOut();
								ga(
									"send",
									"event",
									"Form",
									"submit",
									gaEventLabel
								);
							}
							if (jqXHR.status === 200) {
								if (
									data.status ==
									"User not modified - already subscribed"
								) {
									$resp
										.text(
											"Email address already subscribed!"
										)
										.removeClass("error")
										.addClass("notice")
										.fadeIn();

									ga(
										"send",
										"event",
										"Form",
										"fail",
										"already subscribed"
									);
								}
								if (
									data.status ==
									"User modified - subscription created"
								) {
									$resp
										.text("Thank you for subscribing!")
										.removeClass("notice error")
										.addClass("success")
										.fadeIn();
									$form.find(".input-wrap").fadeOut();
									ga(
										"send",
										"event",
										"Form",
										"submit",
										gaEventLabel
									);
								}
							}

							if ($form.hasClass("bb-flipbook-form")) {
								$form.find(".form-middle .input-wrap").remove();
								$form
									.find(".form-bottom")
									.html(
										'<a class="button" href="https://insights.bookbub.com/wp-content/uploads/2016/04/BookBub-Ultimate-Collection-of-Book-Marketing-Examples.pdf" target="_blank" style="display:block;margin-bottom:10px;">Click here to download</a>'
									);
							}

							if (
								$form.hasClass("bb-flipbook-form") &&
								$form.hasClass("bb-alternate-flipbook-form")
							) {
								$form.find(".form-middle .input-wrap").remove();
								$form
									.find(".form-bottom")
									.html(
										'<a class="button" href="https://insights.bookbub.com/wp-content/uploads/2017/02/how-traditionally-published-authors-market-their-books-bookbub.pdf" target="_blank" style="display:block;margin-bottom:10px;">Click here to download</a>'
									);
							}

							if (
								$form.hasClass("bb-flipbook-form") &&
								$form.hasClass("promoting-book-launch-form")
							) {
								$form.find(".form-middle .input-wrap").remove();
								$form
									.find(".form-bottom")
									.html(
										'<a class="button" href="https://insights.bookbub.com/wp-content/uploads/2018/11/ultimate-guide-to-promoting-a-book-launch-bookbub_file.pdf" target="_blank" style="display:block;margin-bottom:10px;">Click here to download</a>'
									);
							}

							if (
								$form.hasClass("bb-flipbook-form") &&
								$form.hasClass("audiobook-marketing-examples")
							) {
								$form.find(".form-middle .input-wrap").remove();
								$form
									.find(".form-bottom")
									.html(
										'<a class="button" href="https://insights.bookbub.com/wp-content/uploads/2020/07/ultimate-collection-of-audiobook-marketing-examples_bookbub.pdf" target="_blank" style="display:block;margin-bottom:10px;">Click here to download</a>'
									);
							}

							if ($("#pbs-popup-form-div.doc_share").length > 0) {
								$(
									"#pbs-popup-form-div.doc_share .form-middle .input-wrap"
								).remove();
								$(
									"#pbs-popup-form-div.doc_share .form-middle .resp-msg"
								).after(
									'<a class="button" href="' +
										sharedDocHref +
										'" target="_blank" style="display:block;margin-bottom:10px;" data-test="test">Download Now</a>'
								);

								// change button text
								$(
									"#pbs-popup-form-div.doc_share .form-middle .button"
								).text(pop_button_after_submit);

								$form.find(".form-bottom").empty();
							}

							writeDismissCookie();
							writeSignupCookie();
						},
						error: function (jqXHR, textStatus, errorThrown) {
							$button.removeClass("loading");
							$button
								.html($buttonOrig)
								.find("img.loader")
								.remove();
							$resp
								.text(
									"We are unable to process your request at this time."
								)
								.addClass("error")
								.fadeIn();
							console.log("status:" + jqXHR.status);
							console.log("textStatus:" + textStatus);
							console.log("errorThrown:" + errorThrown);
							ga("send", "event", "Form", "fail", "error");
						},
					});
				} else {
					//Error message for email field
					if (validateEmail($email) === false) {
						$form
							.find("input.email-input")
							.addClass("error")
							.parent()
							.after(
								'<div class="err-msg">Please enter a valid email address.</div>'
							);
					}
					//Error message for role selector
					if ($role == "empty") {
						$form
							.find("select.role-input")
							.addClass("error")
							.parent()
							.after(
								'<div class="err-msg">Please select a role.</div>'
							);
					}
				}
			};

			var bbFlipbookFormSubmitDebounced = _.debounce(
				bbFlipbookFormSubmit,
				1000
			);

			$("form.partner-form, form.bb-flipbook-form").on(
				"submit",
				function (e) {
					e.preventDefault();
					var $context = $(this);
					bbFlipbookFormSubmitDebounced($context);
				}
			);

			return false;
		}
	});
})(jQuery);
