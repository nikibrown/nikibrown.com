# Partner Blog signups

This is a super basic wordpress plugin that creates widgets that contain the partner signup form.

FYI, the insights.bookbub.com site is in a different repository: https://github.com/BookBub/insights.bookbub.com/. That repository contains instructions for local development.

For developers modifying this plugin:
* `npm install` to install dependencies.
* `gulp init` to initialize project (install bower components and move to proper location). Default `gulp` will watch for sass/js changes.


# Deploy Process

In `partner_blog_signups.php` there is a update this line to include the current date: `Plugin Name: Partner Blog Signups (updated xx/xx/xxxx)`. This will help you locate the updated plugin in the [WordPress admin plugin section](https://insights.bookbub.com/wp-admin/plugins.php)

![wp admin plugins](https://user-images.githubusercontent.com/43347829/61661921-4b046b80-ac9b-11e9-8d39-66d3a31e3710.jpeg)

When you are ready to deploy your work go into WP Engine and make a back up of [legacy staging](https://my.wpengine.com/installs/bbpartners/backup_points#staging) or [production](https://my.wpengine.com/installs/bbpartners/backup_points#production). Enter your email to be notified when the backup has completed and enter a descrpitive message. 

![backup description](https://user-images.githubusercontent.com/43347829/61661926-4d66c580-ac9b-11e9-8f3b-d16eb5c09069.jpeg)

Once the backup has finished you can SFTP into legacy staging or production. You can find [SFTP info here](https://my.wpengine.com/installs/bbpartners/sftp_users)

Once you have SFTP access setup located the currently enabled plugin in `wp-content/plugins/pluginname` and change the name of the folder by putting an underscore (or 5) in front of it: `_pluginname` This will disable the plugin in the WordPress admin. 

![transmit](https://user-images.githubusercontent.com/43347829/61661927-4f308900-ac9b-11e9-849e-5c813bca84d3.jpeg)

Upload your new plugin (remembering to update the date). Once the upload is complete you can go to the [WordPress admin plugin section](https://insights.bookbub.com/wp-admin/plugins.php) and activate.

Once activated you can delete the unused plugins with underscores in their names to clean things up a bit. 

After activation go back to WP Engine and make a back up of [legacy staging](https://my.wpengine.com/installs/bbpartners/backup_points#staging) or [production](https://my.wpengine.com/installs/bbpartners/backup_points#production). 
