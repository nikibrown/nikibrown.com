<?php
class PopupFormWidget extends WP_Widget {
    public function __construct() {
        $widget_ops = array(
            'classname' => 'partner_blog_form',
            'description' => 'Widget for popup partners signup form.'
        );
        parent::__construct( 'popup_form_widget', 'Partner Signup Form (Popup)', $widget_ops );
    }

    public function widget( $args, $instance ) {

      // Retrieves the stored value from the database
      $meta_value = get_post_meta( get_the_ID(), 'meta-checkbox', true );
      // use meta value to add class to popups to show/hide


      // logic to detext partner email source string in URL to show ignore popups on certain conditions
      $link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

      $text_in_url = "pemail";

      if (strpos($link, $text_in_url) == false) {
          $contains_pemail = false;
      }
      else {
          $contains_pemail = true;
      }

?>
        <?php $postid = get_the_ID(); ?>
        <div id="pbs-popup-form-div" class="
          <?php
            if( get_field('hide_partner_signup_popup', $postid) ) {
              echo "hide-partner-signup-popups";
            }

            if ($contains_pemail === true ) {
             echo "contains-pemail";
           }
          ?>
          "
        >
          <?php require PBS_PLUGIN_DIR . 'includes/partner_forms.php'; ?>
        </div>

<?php
      }
    }
