<?php
class SideFormWidget extends WP_Widget {
    public function __construct() {
        $widget_ops = array(
            'classname' => 'partner_blog_form',
            'description' => 'Widget for sidebar partners signup form.'
        );
        parent::__construct( 'side_form_widget', 'Partner Signup Form (Sidebar)', $widget_ops );
    }

    public function widget( $args, $instance ) {

      if( is_single() && has_tag('bookbub-ads',$post->ID) ){
        $ads_post = true;
      } else {
        $ads_post = false;
      }
?>
      <div id="pbs-side-context">
        <?php require PBS_PLUGIN_DIR . 'includes/partner_forms.php'; ?>
      </div>

      <?php if ( (isset($_COOKIE["partner_type"]) && $_COOKIE["subscribed_to_partner_blog"] !== "true" && $_COOKIE["PBSsignupCookie"] !== "true") || ($ads_post === true && $_COOKIE["subscribed_to_partner_blog"] !== "true" && $_COOKIE["PBSsignupCookie"] !== "true") ) { ?>
        <div id="pbs-side-form-div">
          <?php //require PBS_PLUGIN_DIR . 'includes/forms/blog_sub_form.php';?>
        </div>
      <?php } ?>

<?php
    }
}
