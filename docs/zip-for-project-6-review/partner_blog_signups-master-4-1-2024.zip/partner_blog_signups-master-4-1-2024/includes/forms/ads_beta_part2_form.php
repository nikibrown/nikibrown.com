<div class="bb-cta-form-container">
  <form class="bb-ads-form-part2">
    <input type="hidden" name="form_name" value="bb_ads_beta">
    <input type="hidden" name="emailAddress" value="" />
    <div class="field-wrap">
      <fieldset>
        <legend>
          Have you used auction-based online advertising platforms like Google Ads or Facebook Ads?
        </legend>
        <label for="bbabup1">
          <input type="radio" name="used_platforms" value="Yes" id="bbabup1">
          Yes
        </label>
        <label for="bbabup2">
          <input type="radio" name="used_platforms" value="No" id="bbabup2">
          No
        </label>
      </fieldset>
      <hr>
      <label for="bbus">
        If yes, what metrics did you use to evaluate your campaigns? Were you satisfied with the results?
        <textarea class="partner-blog-input" name="user_satisfaction" id="bbus"></textarea>
      </label>
      <hr>
      <fieldset>
        <legend>
          Do you need help creating your ad, or will you provide your own design?
        </legend>
        <label for="bbnh1">
          <input type="radio" name="need_help" value="I need help with creative." id="bbnh1">
          I need help with creative.
        </label>
        <label for="bbnh2">
          <input type="radio" name="need_help" value="I can provide my own ad creative." id="bbnh2">
          I can provide my own ad creative.
        </label>
        <label for="bbnh3">
          <input type="radio" name="need_help" value="I don't know." id="bbnh3">
          I don't know.
        </label>
      </fieldset>
      <hr>
      <fieldset>
        <legend>
          How much do you currently spend on advertising (any channel, online or off) each month?
        </legend>
        <label for="bbms1">
          <input type="radio" name="monthly_spend" value="<100" id="bbms1">
          Less than $100 per month
        </label>
        <label for="bbms2">
          <input type="radio" name="monthly_spend" value="100-1000" id="bbms2">
          $100-$1000 per month
        </label>
        <label for="bbms3">
          <input type="radio" name="monthly_spend" value=">1000" id="bbms3">
          Over $1000 per month
        </label>
      </fieldset>
      <hr>
      <label for="bbcn">
        Company Name <span>(optional)</span>
        <input class="partner-blog-input" type="text" name="company_name" value="" id="bbcn">
      </label>
      <label for="bbli">
        LinkedIn Profile <span>(optional)</span>
        <input class="partner-blog-input" type="url" name="linkedin_url" value="" id="bbli">
      </label>
    </div>
    <div class="resp-msg"></div>
    <div class="form-bottom">
      <button type="submit" name="button" class="partner-email-submit">Submit</button>
    </div>
  </form>
</div>
