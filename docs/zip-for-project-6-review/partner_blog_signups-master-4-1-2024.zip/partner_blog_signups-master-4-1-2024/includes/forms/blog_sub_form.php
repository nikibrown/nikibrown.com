<div class="partner-form-container">
  <form class="partner-form">
    <div class="form-top">
      <h4 class="form-title">
        Get Email Updates
      </h4>
    </div>
    <div class="form-middle">
      <p>
        Get BookBub's latest book marketing tips &amp; insights straight to your inbox.
      </p>
      <div class="resp-msg"></div>
      <div class="input-wrap text">
        <input type="email" name="emailAddress" placeholder="Enter your email address..." class="partner-blog-input email-input" aria-label="Email Address"/>
      </div>
      <div class="input-wrap select">
        <select name="role" class="partner-blog-input role-input" aria-label="Role">
          <option value="empty">Choose your role...</option>
          <option value="Independent Author">Indie Author</option>
          <option value="Hybrid Author">Hybrid Author</option>
          <option value="Traditionally Published Author">Traditionally Published Author</option>
          <option value="Publisher">Publisher</option>
          <option value="Other">Other</option>
        </select>
      </div>
    </div>
    <div class="form-bottom">
      <a class="dismiss" href="#">Never display this again</a>
        <?php if( get_field('conversion_type_value') ) { ?>
            <input type="hidden" id="conversion-type" name="conversionType" value="<?php the_field('conversion_type_value'); ?>">
        <?php } else { ?>
            <input type="hidden" id="conversion-type" name="conversionType" value="General Blog Subscribe">
        <?php } ?>
      <button type="submit" class="partner-email-submit btn">
        Subscribe
      </button>
    </div>
  </form>
</div>
