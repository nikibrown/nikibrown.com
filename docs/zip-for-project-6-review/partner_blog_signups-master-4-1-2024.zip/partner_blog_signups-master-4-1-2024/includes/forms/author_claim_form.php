<div class="bb-cta-form-container">
  <div class="author-claim-container">
    <div class="content-wrap">
      <div class="form-top">
        <h4 class="form-title">
          Claim Your BookBub Author Profile
        </h4>
      </div>
      <div class="form-middle">
        <p>
          Let millions of BookBub readers discover your books.
        </p>
        <a class="claim-link" href="#" target="_blank">Claim Now</a>
      </div>
    </div>
    <div class="form-bottom">
      <div class="img-wrap">
        <img src="<?php echo plugins_url( 'partner_blog_signups/assets/images/author-profile-2018.png' ); ?>" alt="" />
      </div>
    </div>
  </div>
  <a class="dismiss" href="#">Close</a>
</div>
