<div class="bb-cta-form-container">
  <form class="ads_follow_up_survey">
    <input type="hidden" name="form_name" value="ads_follow_up_survey">
    <input type="hidden" name="emailAddress" value="" />
    <div class="field-wrap">
      <fieldset>
        <legend>
          On a scale of 1 to 5, how likely are you to schedule more BookBub Ads campaigns within the next six months?
        </legend>
        <div class="flex-container">
            <label for="bbUse1">
              <input type="radio" name="satisfaction_score" value="1" id="bbUse1">
              <span class="value">1</span>
              <span class="small-label">Not Likely</span>
            </label>
            <label for="bbUse2">
              <input type="radio" name="satisfaction_score" value="2" id="bbUse2">
              <span class="value">2</span>
            </label>
            <label for="bbUse3">
              <input type="radio" name="satisfaction_score" value="3" id="bbUse3">
              <span class="value">3</span>
            </label>
            <label for="bbUse4">
              <input type="radio" name="satisfaction_score" value="4" id="bbUse4">
              <span class="value">4</span>
            </label>
            <label for="bbUse5">
              <input type="radio" name="satisfaction_score" value="5" id="bbUse5">
              <span class="value">5</span>
              <span class="small-label">Very Likely</span>
            </label>
        </div>
      </fieldset>
      <hr>
      <label for="bbExp">
        Please explain why.
        <textarea class="partner-blog-input" name="satisfaction_reason" id="bbExp"></textarea>
      </label>
      <hr>
      <label for="bbUseful">
        What are two things we could do to make BookBub Ads more useful to you?
        <textarea class="partner-blog-input" name="suggestions" id="bbUseful"></textarea>
      </label>
      <hr>
      <label for="bbFeedback">
        Any other feedback or comments on BookBub Ads?
        <textarea class="partner-blog-input" name="other_comments" id="bbFeedback"></textarea>
      </label>
    </div>
    <div class="resp-msg"></div>
    <div class="form-bottom">
      <button type="submit" name="button" class="partner-email-submit">Submit</button>
    </div>
  </form>
</div>
