<div class="bb-cta-form-container">
  <div class="featured-new-releases-container">
    <div class="content-wrap">
      <div class="form-top">
        <h4 class="form-title">
          Promote a New Book to Millions of Readers
        </h4>
      </div>
      <div class="form-middle">
        <p>
          Drive exposure and full-priced sales with a BookBub Featured New Release.
        </p>
        <a class="claim-link" href="https://partners.bookbub.com/new_release_promotions/new?pd_source=pblog_dcta_featured-new-releases&utm_source=pblog_dcta_featured-new-releases&utm_medium=referral" target="_blank">Submit a Book</a>
      </div>
    </div>
    <div class="form-bottom">
      <div class="img-wrap">
        <img src="<?php echo plugins_url( 'partner_blog_signups/assets/images/featured-new-releases-new.jpg' ); ?>" alt="Promote a New Book to Millions of Readers" />
      </div>
    </div>
  </div>
  <a class="dismiss" href="#">Close</a>
</div>
