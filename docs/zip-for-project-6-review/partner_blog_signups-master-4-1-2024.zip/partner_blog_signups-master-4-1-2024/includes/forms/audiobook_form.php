<div class="bb-cta-form-container">
  <div class="audiobook-container">
    <div class="content-wrap">
      <div class="form-top">
        <h4 class="form-title">
          Promote Your Audiobook Discount
        </h4>
      </div>
      <div class="form-middle">
        <p>
          Run a Chirp Deal to reach new listeners, drive sales, and boost buzz.
        </p>
        <a class="claim-link" href="https://partners.bookbub.com/audiobook_promotions/new?pd_source=pblog_dcta_chirp&utm_source=pblog_dcta_chirp&utm_medium=referral" target="_blank">Submit an Audiobook</a>
      </div>
    </div>
    <div class="form-bottom">
      <div class="img-wrap">
        <img src="<?php echo plugins_url( 'partner_blog_signups/assets/images/chirp-image.jpg' ); ?>" alt="Promote Your Audiobook Discount" />
      </div>
    </div>
  </div>
  <a class="dismiss" href="#">Close</a>
</div>
