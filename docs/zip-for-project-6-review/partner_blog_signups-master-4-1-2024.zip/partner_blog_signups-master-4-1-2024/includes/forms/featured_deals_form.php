<div class="bb-cta-form-container">
  <div class="featured-deals-container">
    <div class="content-wrap">
      <div class="form-top">
        <h4 class="form-title">
          Promote Your Ebook Discount to Millions
        </h4>
      </div>
      <div class="form-middle">
        <p>
          Drive a high volume of sales &amp; revenue with a BookBub Featured Deal.
        </p>
        <a class="claim-link" href="https://partners.bookbub.com/campaigns/select_book?pd_source=pblog_dcta_featured-deals&utm_source=pblog_dcta_featured-deals&utm_medium=referral" target="_blank">Submit a Book</a>
      </div>
    </div>
    <div class="form-bottom">
      <div class="img-wrap">
        <img src="<?php echo plugins_url( 'partner_blog_signups/assets/images/featured-deal.jpg' ); ?>" alt="Promote Your Ebook Discount to Millions" />
      </div>
    </div>
  </div>
  <a class="dismiss" href="#">Close</a>
</div>
