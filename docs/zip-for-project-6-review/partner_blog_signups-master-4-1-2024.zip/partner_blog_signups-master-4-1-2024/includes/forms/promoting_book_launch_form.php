<div class="bb-cta-form-container promoting_book_launch_form">
  <form class="bb-flipbook-form promoting-book-launch-form"  id="bb-flipbook-form">
    <div class="form-top">
      <h4 class="form-title">
        <span>Free:</span> The Ultimate Guide to Promoting a Book Launch
      </h4>
    </div>
    <div class="form-middle">
      <div class="img-wrap">
        <img src="<?php echo plugins_url( 'partner_blog_signups/assets/images/promoting-book-launch.png' ); ?>" alt="" />
      </div>
      <p>
        Subscribe to the BookBub Partners Blog to get your free flipbook right away. You'll also get BookBub’s latest book marketing tips and insights delivered to your inbox each week.
      </p>
      <?php if( $_COOKIE["PBSsignupCookie"] == "true" ) { ?>
        <div class="form-bottom">
          <a class="button" href="https://insights.bookbub.com/ultimate-guide-to-promoting-a-book-launch-bookbub" target="_blank" style="display:block;margin-bottom:10px;">Click here to download</a>
        </div>
      <?php } else { ?>
        <div class="resp-msg"></div>
        <div class="input-wrap text">
          <input type="email" name="emailAddress" placeholder="Enter your email address..." class="partner-blog-input email-input" aria-label="Email Address"/>
        </div>
        <div class="input-wrap select">
          <select name="role" class="partner-blog-input role-input" aria-label="Role">
            <option value="empty">Choose your role...</option>
            <option value="Independent Author">Indie Author</option>
            <option value="Hybrid Author">Hybrid Author</option>
            <option value="Traditionally Published Author">Traditionally Published Author</option>
            <option value="Publisher">Publisher</option>
            <option value="Other">Other</option>
          </select>
          <input type="hidden" id="conversion-type" name="conversionType" value="The Ultimate Guide to Promoting a Book Launch">
          <i class="fa fa-angle-down" aria-hidden="true"></i>
        </div>
      </div>
      <div class="form-bottom">
        <button type="submit" class="partner-email-submit btn">
          Download Now
        </button>
      </div>
    <?php } ?>
  </form>
  <a class="dismiss" href="#">Close</a>
</div>
