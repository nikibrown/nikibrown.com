<div class="bb-cta-form-container">
    <form class="bb-ads-form">
        <input type="hidden" name="source" value="">
        <div class="form-top">
            <div class="form-top-content">
                <h4 class="form-title">
                    Set Up a BookBub Ads Campaign
                </h4>
                <p>Promote any book, any time with our self-serve advertising platform.</p>
                <a href="https://partners.bookbub.com/ads/new?pd_source=pblog_dcta_ads&utm_source=pblog_dcta_ads&utm_medium=referral" class="partner-email-submit btn"  target="_blank">
                    Create An Ad Now
                </a>
            </div>
        </div>
        <div class="content-wrap">
            <div class="form-bottom">
                <div class="img-wrap">
                    <img src="<?php echo plugins_url( 'partner_blog_signups/assets/images/bookbub-ad-cta.png' ); ?>" alt="Set Up a BookBub Ads Campaign" />
                </div>
            </div>
        </div>
    </form>
    <a class="dismiss" href="#">Close</a>
</div>
