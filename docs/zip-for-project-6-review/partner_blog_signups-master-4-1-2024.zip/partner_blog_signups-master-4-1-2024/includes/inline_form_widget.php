<?php
class InlineFormWidget extends WP_Widget {
    public function __construct() {
        $widget_ops = array(
            'classname' => 'partner_blog_form',
            'description' => 'Widget for inline partners signup form.'
        );
        parent::__construct( 'inline_form_widget', 'Partner Signup Form (Inline)', $widget_ops );
    }

    public function widget( $args, $instance ) {
?>
      <div id="pbs-inline-form-div">
        <?php require PBS_PLUGIN_DIR . 'includes/forms/blog_sub_form.php'; ?>
      </div>
<?php
    }
}
