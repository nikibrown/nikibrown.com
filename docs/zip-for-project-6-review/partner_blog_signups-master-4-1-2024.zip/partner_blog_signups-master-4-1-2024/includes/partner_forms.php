<?php

// flowchart of logic can be viewed here: https://miro.com/app/board/o9J_kwLsc9k=/ contact hi@nikibrown.com for access

if( is_single() && has_tag('bookbub-ads',$post->ID) ){
  $ads_post = true;
} else {
  $ads_post = false;
}

if( is_single() && has_tag('chirp',$post->ID) ){
  $audiobook_post = true;
} else {
  $audiobook_post = false;
}

if( is_single() && has_tag('bookbub-featured-deals',$post->ID) ){
  $deal_post = true;
} else {
  $deal_post = false;
}

if( is_single() && has_tag('featured-new-releases',$post->ID) ){
  $new_release_post = true;
} else {
  $new_release_post = false;
}

if( is_single() && has_tag('preorder-alerts',$post->ID) ){
	$preorder_post = true;
} else {
	$preorder_post = false;
}

if( is_single() && has_tag('the-ultimate-collection-of-audiobook-marketing-examples',$post->ID) ){
	$audiobook_marketing_post = true;
} else {
	$audiobook_marketing_post = false;
}

//WP Engine caches $_COOKIE aggressively - these values must be added to their exclusion list on the relevant install

if ( $_COOKIE["subscribed_to_partner_blog"] !== "true" && $_COOKIE["PBSsignupCookie"] !== "true" ) {
    if ( has_tag('how-traditionally-published-authors-market-their-books',$post->ID) ) {
        require PBS_PLUGIN_DIR . 'includes/forms/alternate_nonsubscriber_form.php';
    } elseif ( has_tag('the-ultimate-guide-to-promoting-a-book-launch', $post->ID) ) {
        require PBS_PLUGIN_DIR . 'includes/forms/promoting_book_launch_form.php';
    } elseif ( has_tag('the-ultimate-collection-of-audiobook-marketing-examples', $post->ID) ) {
        require PBS_PLUGIN_DIR . 'includes/forms/audiobook_marketing_examples.php';
    } else {
         require PBS_PLUGIN_DIR . 'includes/forms/flipbook_form.php';
    }
}

// Audiobook
if ( $_COOKIE["subscribed_to_partner_blog"] == "true" && $audiobook_post === true ) {
    require PBS_PLUGIN_DIR . 'includes/forms/audiobook_form.php';
}

// Featured new releases
if ( $_COOKIE["subscribed_to_partner_blog"] == "true" && $new_release_post === true ) {
    require PBS_PLUGIN_DIR . 'includes/forms/featured_new_releases_form.php';
}

// Featured Deals
if ( $_COOKIE["subscribed_to_partner_blog"] == "true" && $deal_post === true ) {
    require PBS_PLUGIN_DIR . 'includes/forms/featured_deals_form.php';
}



// Author claim form
if ( $audiobook_marketing_post === false && $preorder_post === false && $ads_post === false && $audiobook_post === false && $new_release_post === false && $deal_post === false && $_COOKIE["subscribed_to_partner_blog"] == "true" ) {
  require PBS_PLUGIN_DIR . 'includes/forms/author_claim_form.php';
}

// if preorder post and subscribed to blog
if( $preorder_post === true &&  $_COOKIE["subscribed_to_partner_blog"] == "true" ){
	require PBS_PLUGIN_DIR . 'includes/forms/preorder_alert_form.php';
}

if ( ($ads_post === true && $_COOKIE["subscribed_to_partner_blog"] == "true") ) {
  require PBS_PLUGIN_DIR . 'includes/forms/ads_beta_form.php';
} ?>
