<?php
class BottomFormWidget extends WP_Widget {
    public function __construct() {
        $widget_ops = array(
            'classname' => 'partner_blog_form',
            'description' => 'Widget for bottom of post partners signup form.'
        );
        parent::__construct( 'bottom_form_widget', 'Partner Signup Form (Bottom)', $widget_ops );
    }

    public function widget( $args, $instance ) { ?>
        <div id="pbs-bottom-form-div">
          <?php require PBS_PLUGIN_DIR . 'includes/partner_forms.php'; ?>
        </div>

      <?

    }
}
