<?php
class HeaderFormWidget extends WP_Widget {
    public function __construct() {
        $widget_ops = array(
            'classname' => 'partner_blog_form',
            'description' => 'Widget for header partners signup form.'
        );
        parent::__construct( 'header_form_widget', 'Partner Signup Form (Header)', $widget_ops );
    }

    public function widget( $args, $instance ) {
?>
      <div id="pbs-header-form-div">
        <?php require PBS_PLUGIN_DIR . 'includes/partner_forms.php'; ?>
      </div>
<?php
    }
}
