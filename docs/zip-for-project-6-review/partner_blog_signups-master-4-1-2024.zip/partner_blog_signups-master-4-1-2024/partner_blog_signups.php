<?php
/*
Plugin Name: Partner Blog Signups (updated 1/12/21)
Description: Creates widgets that contain the partner signup form.
*/

if ( ! defined( 'PBS_PLUGIN_DIR' ) )
  define( 'PBS_PLUGIN_DIR', dirname( __FILE__ ) . '/' );

require_once PBS_PLUGIN_DIR . 'includes/side_form_widget.php';
require_once PBS_PLUGIN_DIR . 'includes/blog_side_form_widget.php';
require_once PBS_PLUGIN_DIR . 'includes/popup_form_widget.php';
require_once PBS_PLUGIN_DIR . 'includes/bottom_form_widget.php';
require_once PBS_PLUGIN_DIR . 'includes/inline_form_widget.php';
require_once PBS_PLUGIN_DIR . 'includes/header_form_widget.php';

/**
 * Register style sheet.
 */
function register_plugin_assets() {
  if (is_admin()) return;
	wp_enqueue_style( 'pbs-styles', plugins_url( 'assets/css/main.css', __FILE__ ) );
    wp_enqueue_script( 'pbs-scripts', plugins_url( 'assets/js/main.js', __FILE__ ), array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'pbs-underscore', plugins_url( 'assets/js/min/underscore-min.js', __FILE__ ) );
    wp_localize_script( 'pbs-scripts', 'WPURLS', array( 'plugins_url' => plugins_url( '', __FILE__ ) ) );//Register plugin url as a JS var
}
add_action( 'wp_enqueue_scripts', 'register_plugin_assets' );

/**
 * Register widgets.
 */
function register_form_widgets() {
    register_widget( 'SideFormWidget' );
    register_widget( 'BlogSideFormWidget' );
    register_widget( 'BottomFormWidget' );
    register_widget( 'PopupFormWidget' );
    register_widget( 'InlineFormWidget' );
    register_widget( 'HeaderFormWidget' );
}
add_action( 'widgets_init', 'register_form_widgets' );

/**
 * Output buffering for inline form
 */
function clean_partners_form() {
	ob_start();
	the_widget('InlineFormWidget');
	return ob_get_clean();
}

/**
 * Set up shortcode for inline form
 */
function pbs_shortcode_handler( $atts, $content = "" ) {
  $content .= clean_partners_form();
	return $content;
}
add_shortcode( 'pbs_form', 'pbs_shortcode_handler' );

/**
 * Shortcode for Ads Beta form
 */
function pbs_ads_beta_form() {
  ob_start();
  require PBS_PLUGIN_DIR . 'includes/forms/ads_beta_part2_form.php';
  return ob_get_clean();
}
add_shortcode( 'ads_beta_form', 'pbs_ads_beta_form' );

/**
 * Shortcode for Ads Follow-up form
 */
function pbs_ads_follow_up_form() {
  ob_start();
  require PBS_PLUGIN_DIR . 'includes/forms/ads_follow_up_survey.php';
  return ob_get_clean();
}
add_shortcode( 'ads_follow_up_form', 'pbs_ads_follow_up_form' );
