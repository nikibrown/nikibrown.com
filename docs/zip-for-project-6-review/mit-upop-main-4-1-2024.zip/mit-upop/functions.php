<?php
/**
 * mitupop functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package mitupop
 */

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}

function mitupop_setup() {
    /*
    * Let WordPress manage the document title.
    * By adding theme support, we declare that this theme does not use a
    * hard-coded <title> tag in the document head, and expect WordPress to
    * provide it for us.
    */
    add_theme_support( 'title-tag' );
}

add_action( 'after_setup_theme', 'mitupop_setup' );

/**
 * Enqueue scripts and styles.
 */
function mitupop_scripts() {
		wp_enqueue_style(  'global', get_template_directory_uri() . '/assets/css/min/global.css', array(), '1.1', 'all');
}
add_action( 'wp_enqueue_scripts', 'mitupop_scripts' );

/* ACF Blocks */

add_action( 'init', 'register_acf_blocks' );
function register_acf_blocks() {
    register_block_type( __DIR__ . '/blocks/lead-paragraph' );
    register_block_type( __DIR__ . '/blocks/profile-cards' );
	register_block_type( __DIR__ . '/blocks/buttons' );
	register_block_type( __DIR__ . '/blocks/accordion' );
	register_block_type( __DIR__ . '/blocks/cards' );
}


function column_func($atts, $content=""){
    return '<div class="col">'.$content.'</div>';
}
add_shortcode( 'col', 'column_func');

function row_func($atts, $content=""){
	return '<div class="row">' . do_shortcode($content) . '</div>';
}
add_shortcode( 'row', 'row_func');


// add typogrpahic styles to WP Editor
function load_editor_style() {
  add_editor_style( get_template_directory_uri() . '/assets/css/global.css' );
}
add_action( 'after_setup_theme', 'load_editor_style' );


/**
 *  Remove the headings from the WordPress TinyMCE editor.
 *
 *  @param   array  $settings  The array of editor settings
 *  @return  array             The modified edit settings
 */
 
function my_format_TinyMCE( $in ) {
        $in['block_formats'] = "Paragraph=p;Heading 2=h2;Heading 3=h3;Heading 4=h4;";
    return $in;
}
add_filter( 'tiny_mce_before_init', 'my_format_TinyMCE' );



/**
 * Bootstrap navwalker for custom WP Menu markup
 */

require_once('wp_bootstrap_navwalker.php');

function add_nav_menus() {
    register_nav_menus( array(
        'header-menu'=>'Header Menu',
    ));
}
add_action('init', 'add_nav_menus');


/*
 * ACF Options pages
 *
 */

add_action('acf/init', 'my_acf_op_init');
function my_acf_op_init() {

    // Check function exists.
    if( function_exists('acf_add_options_page') ) {

        // Register options page.
        $option_page = acf_add_options_page(array(
            'page_title'    => __('Theme General Settings'),
            'menu_title'    => __('Theme Settings'),
            'menu_slug'     => 'theme-general-settings',
            'capability'    => 'edit_posts',
            'redirect'      => false
        ));
    }
}

// set index of repeater rows to start at 0
add_filter('acf/settings/row_index_offset', '__return_zero');


// Allow SVG
add_filter( 'wp_check_filetype_and_ext', function($data, $file, $filename, $mimes) {

  global $wp_version;
  if ( $wp_version !== '4.7.1' ) {
     return $data;
  }

  $filetype = wp_check_filetype( $filename, $mimes );

  return [
      'ext'             => $filetype['ext'],
      'type'            => $filetype['type'],
      'proper_filename' => $data['proper_filename']
  ];

}, 10, 4 );

function cc_mime_types( $mimes ){
  $mimes['svg'] = 'image/svg+xml';
  return $mimes;
}
add_filter( 'upload_mimes', 'cc_mime_types' );

function fix_svg() {
  echo '<style type="text/css">
        .attachment-266x266, .thumbnail img {
             width: 100% !important;
             height: auto !important;
        }
        </style>';
}
add_action( 'admin_head', 'fix_svg' );