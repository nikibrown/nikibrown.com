# MIT UPOP https://upop.mit.edu/

## Running locally

- To run site localy use https://localwp.com/. Select connect from left sidebar and pull a copy of MIT UPOP from wpengine account. Contact niki@zaydmedia.com for access. 

- Delete mit-upop theme

- Clone theme files from https://github.com/nikibrown/mit-upop

- To compile scss, minify, purge, update block css see gulpfile.js or run `gulp`

- Site structure is built on https://getbootstrap.com/

- Contact niki@zaydmedia.com for any question




