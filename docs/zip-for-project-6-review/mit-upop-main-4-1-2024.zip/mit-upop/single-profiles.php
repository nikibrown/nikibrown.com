<?php
/**
 * The template for displaying all single profile pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package mitupop
 */

get_header();
?>

<?php get_template_part( 'template-parts/hero' ); ?>

<section class="page-intro">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1><?php the_title(); ?></h1>
            </div>
            <div class="col-lg-3 d-none d-lg-block">
                <div class="col-inner">
                    <?php get_sidebar(); ?>
                </div>
            </div>
            <div class="col-lg-9">
                <div class="col-inner">
                    <article>
                        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

                        <div class="row">
                            <div class="col-lg-8">
                                <h2 class="lead"><?php the_field("name"); ?></h2>
                                <p><strong><?php the_field("job_title"); ?></strong><br />
                                    <a href="mailto:<?php the_field("email"); ?>">
                                        <?php the_field("email"); ?>
                                    </a><br />
                                    <?php the_field("phone"); ?>
                                </p>

                                <?php the_field("bio"); ?>
                            </div>
                            <div class="col-lg-4">
                                <?php 
                                $overlay_color = get_field("photo_overlay_color");  
                                $headshot = get_field("photo"); 
                                ?>
                                <div class="profile-container overlay-color-<?php echo $overlay_color; ?>">
                                    <?php echo wp_get_attachment_image( $headshot, 'full',false, array('class' => 'profile-headshot' )); ?>
                                </div>

                                <p><a href="<?php the_field("linkedin_url"); ?>">
                                        Linkedin
                                    </a></p>
                            </div>
                            <div class="col-lg-12 mt-3">
                                <a href="<?php echo esc_url( get_permalink(230) ); ?>"
                                    class="btn btn-text-icon-left">Back To Team</a>
                            </div>
                        </div>
                        <?php endwhile; endif; ?>
                    </article>
                </div>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>