<?php
/**
 * Template part for displaying CTA banner
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package mitupop
 */

?>

<?php  if( get_field('show_cta_banner') ) { ?>

<section class="cta-banner">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="lead"><?php the_field("cta_banner_headline", "option"); ?></h2>
            </div>
        </div>
    </div>
    <div class="cta-banner-inner">
        <div class="container">
            <div class="row">
                <div class="col-lg-9">
                    <p>
                        <?php the_field("cta_banner_text", "option"); ?>
                    </p>
                </div>
                <div class="col-lg-3">
                    <a href="<?php the_field("cta_banner_button_link", "option"); ?>"
                        class="btn btn-tertiary ms-auto"><?php the_field("cta_banner_button_text", "option"); ?></a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php } ?>