<?php
/**
 * Homepage Slider
 *
 * @package mitupop
 */

?>

<section id="primary" class="hero-slider">
    <div class="hero-slider-slides">
        <div class="bar bar-purple animate"></div>
        <div class="bar bar-pink animate"></div>
        <div class="bar bar-orange animate"></div>
        <div class="bar bar-blue animate"></div>
        <div class="bar bar-blue2 animate"></div>

        <?php if( have_rows('hero_slider') ): while( have_rows('hero_slider') ): the_row();  
            $slider_image = get_sub_field('slider_image'); 
            $index = get_row_index(); // 0
            $index++; // 1
        ?>

        <div class="hero-slider-slide img-<?php echo $index; ?> animated-img"
            style="display: <?php if( $index == 1) { ?>block<?php } else { ?>none<?php } ?>">
            <?php echo wp_get_attachment_image( $slider_image, 'full' ); ?>
        </div>
        <?php endwhile; endif; ?>
    </div>



    <div class="hero-slider-nav">
        <div class="hero-slider-nav-inner" style="position: relative">
            <div class="container">

                <div class="row">
                    <?php if( have_rows('hero_slider') ): while( have_rows('hero_slider') ): the_row(); 
                    $index = get_row_index(); // 0
                    $index++; // 1
                ?>

                    <div class="col-lg-4" style="position: relative;">
                        <div data-slide-btn=""
                            class="btn-container btn-container-<?php echo $index; ?> <?php if( $index == 1) { ?>active-btn<?php } ?>">
                            <button
                                class="btn btn-outline button-<?php echo $index; ?>"><?php the_sub_field('slider_headline'); ?></button>
                            <div class="slide-text-container slide-text-<?php echo $index; ?>"
                                style="display: <?php if( $index == 1) { ?>block<?php } else { ?>none<?php } ?>">
                                <?php the_sub_field('slider_text'); ?>
                            </div>
                        </div>
                        <span class="line-arrow">&nbsp;</span>
                    </div>

                    <?php endwhile; endif; ?>
                </div>
            </div>
        </div>

        <span class="badge text-bg-light play-pause state-pause">
            <svg class="icon icon-play" xmlns="http://www.w3.org/2000/svg" height="16" width="12" viewBox="0 0 384 512">
                <path
                    d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80V432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z" />
            </svg>
            <svg class="icon icon-pause" xmlns="http://www.w3.org/2000/svg" height="16" width="12"
                viewBox="0 0 320 512">
                <path
                    d="M48 64C21.5 64 0 85.5 0 112V400c0 26.5 21.5 48 48 48H80c26.5 0 48-21.5 48-48V112c0-26.5-21.5-48-48-48H48zm192 0c-26.5 0-48 21.5-48 48V400c0 26.5 21.5 48 48 48h32c26.5 0 48-21.5 48-48V112c0-26.5-21.5-48-48-48H240z" />
            </svg>
        </span>
    </div>
</section>

<script src="<?php bloginfo("template_url"); ?>/assets/js/home-slider.js"></script>