<?php
/**
 * Template part for displaying sponsors
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package mitupop
 */

?>

<section class="sponsors">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="lead">
                    <?php the_field('sponsors_headline'); ?>
                </h2>
                <div class="slider-container">
                    <div class="slider">
                        <?php if( have_rows('slider') ): ?>
                        <?php while( have_rows('slider') ): the_row(); 
                        $slider_image = get_sub_field('slider_image'); ?>

                        <div>
                            <?php echo wp_get_attachment_image( $slider_image, 'full' ); ?>
                        </div>
                        <?php endwhile; ?> <?php endif; ?>
                    </div>
                    <div aria-label="Previous" class="glider-prev">«</div>
                    <div aria-label="Next" class="glider-next">»</div>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="<?php bloginfo("template_url"); ?>/assets/js/glider.min.js"></script>

<script>
window.addEventListener("load", () => {
    new Glider(document.querySelector(".slider"), {
        slidesToShow: 1,
        arrows: {
            prev: ".glider-prev",
            next: ".glider-next",
        },
        responsive: [{
            // screens greater than >= 775px
            breakpoint: 775,
            settings: {
                // Set to `auto` and provide item width to adjust to viewport
                slidesToShow: 2,
                slidesToScroll: 1,

            }
        }, {
            // screens greater than >= 1024px
            breakpoint: 1024,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1,

            }
        }]
    });
});
</script>