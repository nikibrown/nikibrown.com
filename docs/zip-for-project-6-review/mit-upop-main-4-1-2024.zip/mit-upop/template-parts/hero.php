<?php if ( get_field('page_hero_image') ) {
    $page_hero_image = get_field("page_hero_image");
} else {
    $page_hero_image = get_field("page_hero_image", "option");
} ?>

<section class="hero">
    <?php echo wp_get_attachment_image( $page_hero_image, 'full'); ?>
</section>