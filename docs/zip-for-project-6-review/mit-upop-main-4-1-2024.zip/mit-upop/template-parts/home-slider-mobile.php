<?php
/**
 * Template part for displaying a message that posts cannot be found
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package mitupop
 */

?>

<section class="hero-slider-mobile">

    <div class="mobile-slider-container">
        <?php if( have_rows('hero_slider') ): while( have_rows('hero_slider') ): the_row();  ?>
        <div class="slide">
            <div class="mobile-img-container">
                <?php $slider_image = get_sub_field('slider_image'); 
                echo wp_get_attachment_image( $slider_image, 'full', false, array('class' => 'mobile-img') ); 
            ?>
            </div>

            <div class="slide-text">
                <div class="container">
                    <button class="btn btn-light"><?php the_sub_field('slider_headline'); ?></button>
                    <?php the_sub_field('slider_text'); ?>
                </div>

            </div>


        </div>
        <?php endwhile; ?>
        <?php endif; ?>
    </div>
    <div class="dots"></div>
</section>


<script>
window.addEventListener("load", () => {
    new Glider(document.querySelector(".mobile-slider-container"), {
        slidesToShow: 1,
        dots: '.dots',
        scrollLock: true,
    });
});
</script>