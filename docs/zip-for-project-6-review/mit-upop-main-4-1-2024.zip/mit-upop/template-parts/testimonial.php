<?php
/**
 * Template part for displaying testimonial
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package mitupop
 */

?>
<?php $testimonials = get_field('testimonial'); if( $testimonials ): ?>
<?php foreach( $testimonials as $post ): setup_postdata($post); ?>

<section class="testimonial diagonal-gradient">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <?php if( get_field('photo_or_video') == 'photo' ) { ?>
                <?php $testimonial_photo = get_field('testimonial_photo'); ?>
                <?php echo wp_get_attachment_image( $testimonial_photo, 'full',false, array('class' => 'img-fluid')); ?>
                <?php } else { ?>
                <div class="embed-container">
                    <?php the_field('testimonial_video'); ?>
                </div>
                <?php } ?>
            </div>
            <div class="col-lg-6">
                <blockquote class="has-orange-bar">
                    <p><?php the_field("testimonial_text"); ?> &rdquo;</p>
                    <cite>
                        <?php the_field("testimonial_attribution"); ?>
                    </cite>
                </blockquote>
            </div>
        </div>
    </div>
</section>
<?php endforeach; ?>
<?php wp_reset_postdata(); ?>
<?php endif; ?>