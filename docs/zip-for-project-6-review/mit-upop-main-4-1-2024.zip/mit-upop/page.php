<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package mitupop
 */

get_header();
?>

<?php get_template_part( 'template-parts/hero' ); ?>

<section id="primary" class="page-intro">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1><?php the_title(); ?></h1>
            </div>
            <div class="col-lg-3 d-none d-lg-block">
                <div class="col-inner">
                    <?php get_sidebar(); ?>
                </div>
            </div>
            <div class="col-lg-9">
                <div class="col-inner">
                    <article>
                        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                        <?php the_content(); ?>
                        <?php endwhile; endif; ?>
                    </article>
                </div>
            </div>
        </div>
    </div>
</section>

<?php if( have_rows('additional_page_sections') ): ?>
<main>
    <div class="container">
        <div class="row">
            <aside class="col-lg-3">
                <?php if( have_rows('sidebar_item') ): ?>
                <?php while( have_rows('sidebar_item') ): the_row(); ?>
                <div class="widget">
                    <div class="widget-title">
                        <h3><?php the_sub_field("sidebar_item_headline"); ?></h3>
                    </div>
                    <div class="widget-body">
                        <?php the_sub_field("sidebar_item_content"); ?>
                    </div>
                </div>
                <?php endwhile; ?>
                <?php endif; ?>

            </aside>

            <article class="col-lg-9">

                <?php while( have_rows('additional_page_sections') ): the_row(); ?>
                <?php if( get_row_layout() == 'regular_content' ): ?>
                <?php the_sub_field('content'); ?>
                <?php elseif( get_row_layout() == 'accordion_content' ): ?>

                <?php $headline = get_sub_field( 'accordion_headline' );
                    $fullcontent = get_sub_field("accordion_full_width_column");
                    $leftcontent = get_sub_field("accordion_left_column");
                    $rightcontent = get_sub_field("accordion_right_column");
                    $open = get_sub_field("accordion_is_open");
                    $layout = get_sub_field("accordion_layout"); 
                ?>


                <details <?php if($open): ?>open<?php endif; ?>>
                    <summary>
                        <?php echo $headline; ?>
                    </summary>
                    <div class="details-expanded">
                        <?php if( $layout == "one") { ?>
                        <?php echo $fullcontent; ?>
                        <?php } else { ?>
                        <div class="row">
                            <div class="col-lg-4">
                                <?php echo $leftcontent; ?>
                            </div>
                            <div class="col-lg-8">
                                <?php echo $rightcontent; ?>
                            </div>
                        </div>
                        <?php } ?>

                    </div>
                </details>

                <?php endif; ?>
                <?php endwhile; ?>

            </article>
        </div>
    </div>
</main>

<?php endif; ?>

<?php get_template_part( 'template-parts/testimonial' ); ?>
<?php get_template_part( 'template-parts/cta-banner' ); ?>
<?php get_footer(); ?>