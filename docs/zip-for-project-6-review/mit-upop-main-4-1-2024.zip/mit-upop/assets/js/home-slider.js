let isPlaying = true // Initial state is playing
let currentSlideIndex = 1 // Slide to start from
let slideTimerInMs = 10000

const desktopSlider = document.querySelector(".hero-slider")

document.addEventListener("DOMContentLoaded", function () {
	desktopSlider.classList.add("hero-slider-fadein")
})

const bars = document.querySelectorAll(".bar")
const slides = document.querySelectorAll(".slide-text-container")
const playPause = document.querySelector(".play-pause")

// event listner for playPause
playPause.addEventListener("click", togglePlayPause)

// event listeners for btns
let slideButtons = document.querySelectorAll(".hero-slider-nav .btn")
slideButtons.forEach((button, index) => {
	button.addEventListener("click", () => {
		showClickedSlide(index + 1)
	})
})

function showClickedSlide(clickedSlideIndex) {
	// when a new slide is clicked we hide the current slide
	document.querySelector(`.slide-text-${currentSlideIndex}`).style.display = "none"
	document.querySelector(`.img-${currentSlideIndex}`).style.display = "none"
	document.querySelector(`.btn-container-${currentSlideIndex}`).classList.remove("active-btn")

	// Show the clicked slide
	document.querySelector(`.slide-text-${clickedSlideIndex}`).style.display = "block"
	document.querySelector(`.img-${clickedSlideIndex}`).style.display = "block"
	document.querySelector(`.btn-container-${clickedSlideIndex}`).classList.add("active-btn")

	animateBars()

	// Update currentSlide index to clickedSlide index to let slider continue playing
	currentSlideIndex = clickedSlideIndex

	// Reset timer for automatic cycling if playing
	if (isPlaying) {
		clearInterval(slideInterval)
		slideInterval = setInterval(showNextSlide, slideTimerInMs)
	}
}

function showNextSlide() {
	// hide the current slide
	document.querySelector(`.slide-text-${currentSlideIndex}`).style.display = "none"
	document.querySelector(`.img-${currentSlideIndex}`).style.display = "none"
	document.querySelector(`.btn-container-${currentSlideIndex}`).classList.remove("active-btn")

	animateBars()

	// Show the next slide, if at the end go back to 1
	currentSlideIndex = (currentSlideIndex % slides.length) + 1
	document.querySelector(`.slide-text-${currentSlideIndex}`).style.display = "block"
	document.querySelector(`.img-${currentSlideIndex}`).style.display = "block"
	document.querySelector(`.btn-container-${currentSlideIndex}`).classList.add("active-btn")
}

function togglePlayPause() {
	isPlaying = !isPlaying

	// If playing, start or resume the interval
	if (isPlaying) {
		slideInterval = setInterval(showNextSlide, slideTimerInMs)
		playPause.classList.remove("state-play")
		playPause.classList.add("state-pause")
	} else {
		// If pausing, clear the interval
		clearInterval(slideInterval)
		playPause.classList.remove("state-pause")
		playPause.classList.add("state-play")
	}
}

function animateBars() {
	// classes make bars animate from side to side
	bars.forEach(function (bar) {
		if (bar.classList.contains("animate")) {
			bar.classList.remove("animate")
			bar.classList.add("animate-again")
		} else if (bar.classList.contains("animate-again")) {
			bar.classList.remove("animate-again")
			bar.classList.add("animate")
		} else {
			bar.classList.add("animate")
		}
	})
}

// Set initial interval for automatic cycling
let slideInterval = setInterval(showNextSlide, slideTimerInMs)
