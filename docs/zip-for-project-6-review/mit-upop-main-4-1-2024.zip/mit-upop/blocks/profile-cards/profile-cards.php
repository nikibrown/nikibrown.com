<?php
/**
 * Card Block
 *
 */

    // Load values and assign defaults.
    $profile_cards = get_field("profile_card");

?>
<?php if( $profile_cards ): ?>
<?php foreach( $profile_cards as $profile_card ): 
    $permalink = get_permalink( $profile_card->ID );
    $name = get_field('name', $profile_card->ID );
    $jobtitle = get_field( 'job_title',$profile_card->ID );
    $headshot = get_field( 'photo', $profile_card->ID );
    $overlay_color = get_field( 'photo_overlay_color', $profile_card->ID );
?>
<a href="<?php echo $permalink; ?>" class="profile-card">
    <div class="profile-container overlay-color-<?php echo $overlay_color; ?>">
        <?php echo wp_get_attachment_image( $headshot, 'full',false, array('class' => 'profile-headshot' )); ?>
    </div>

    <p>
        <strong><?php echo $name; ?></strong><br />
        <?php echo $jobtitle; ?>
    </p>

    <?php endforeach; ?>
    <?php endif; ?>
</a>