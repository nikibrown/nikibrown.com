<?php
/**
 * Lead Paragraph Block Template.
 *
 */

// Load values and assign defaults.
    $text = get_field( 'button_text' ) ?: 'Button Text';
    $link = get_field("button_link") ?: 'https://website.com';
    $btntype = get_field("button_type") ?: 'primary';
?>

<a href="<?php echo $link; ?>" class="btn <?php echo $btntype; ?>">
    <?php echo esc_html( $text ); ?>
</a>