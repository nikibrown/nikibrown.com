<?php
/**
 * Lead Paragraph Block Template.
 *
 */

// Load values and assign defaults.
$text = get_field( 'lead_paragraph' ) ?: '';
?>

<h2 class="lead">
    <?php echo $text; ?>
</h2>