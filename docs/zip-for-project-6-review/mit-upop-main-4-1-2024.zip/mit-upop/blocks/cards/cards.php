<?php
/**
 * Card Block
 *
 */

    // Load values and assign defaults.
    $card_image = get_field("card_image");
    $card_title = get_field( 'card_title' );
    $card_content = get_field("card_content");
    $card_btn_link = get_field("card_btn_link");
    $card_btn_text = get_field("card_btn_text");
?>

<div class="card h-100">
    <?php echo wp_get_attachment_image( $card_image, 'full',false, array('class' => 'card-img-top')); ?>

    <h2 class="card-title">
        <?php echo $card_title; ?>
    </h2>
    <div class="card-body">
        <div class="card-text">
            <?php echo $card_content; ?>
        </div>
        <a href="<?php echo $card_btn_link; ?>" class="btn btn-quaternary"><?php echo $card_btn_text; ?></a>
    </div>
</div>