<?php
/**
 * Accordion Block
 *
 */

// Load values and assign defaults.
    $headline = get_field( 'accordion_headline' );
    $fullcontent = get_field("accordion_full_width_column");
    $leftcontent = get_field("accordion_left_column");
    $rightcontent = get_field("accordion_right_column");
    $open = get_field("accordion_is_open");
    $layout = get_field("accordion_layout");
?>

<details <?php if($open): ?>open<?php endif; ?>>
    <summary>
        <?php echo $headline; ?>
    </summary>
    <div class="details-expanded">
        <?php if( $layout == "one") { ?>
        <?php echo $fullcontent; ?>
        <?php } else { ?>
        <div class="row">
            <div class="col-lg-4">
                <?php echo $leftcontent; ?>
            </div>
            <div class="col-lg-8">
                <?php echo $rightcontent; ?>
            </div>
        </div>
        <?php } ?>

    </div>
</details>