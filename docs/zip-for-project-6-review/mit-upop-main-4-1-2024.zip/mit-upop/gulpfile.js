const { series } = require("gulp")
const gulp = require("gulp")
const sass = require("gulp-sass")(require("sass"))
const purgecss = require("gulp-purgecss")
const cleanCSS = require("gulp-clean-css")
const rename = require("gulp-rename")
const path = require("path")

function minify() {
	return gulp
		.src("./assets/css/purge/global.css")
		.pipe(
			cleanCSS({ debug: true }, (details) => {
				console.log(`${details.name}: ${details.stats.originalSize}`)
				console.log(`${details.name}: ${details.stats.minifiedSize}`)
			})
		)
		.pipe(gulp.dest("./assets/css/min/"))
}

// gets rid if unused CSS. Use /*! purgecss start ignore */  /*! purgecss end ignore */
function purge() {
	return gulp
		.src("./assets/css/global.css")
		.pipe(
			purgecss({
				content: ["./**/*.php"],
				keyframes: false,
				variables: true,
			})
		)
		.pipe(gulp.dest("./assets/css/purge/"))
}

function style() {
	return gulp.src("./assets/scss/*.scss").pipe(sass()).on("error", sass.logError).pipe(gulp.dest("./assets/css"))
}

// Compiles scss for blocks in blocks/blockname
function styleBlocks() {
	return gulp
		.src("./assets/scss/blocks/*.scss")
		.pipe(sass().on("error", sass.logError))
		.pipe(
			rename(function (file) {
				const fileName = path.basename(file.basename, path.extname(file.basename))
				file.dirname = path.join(fileName)
				file.basename = fileName
			})
		)
		.pipe(gulp.dest("./blocks/"))
}

gulp.task("styleBlocks", styleBlocks)

gulp.task("purge", purge)

gulp.task("minify", minify)

gulp.task("style", style)

// do all the things
exports.default = function () {
	gulp.watch("./assets/scss/**/*").on("change", series(style, styleBlocks, purge, minify))
}
