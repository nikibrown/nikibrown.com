<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package mitupop
 */

?>
<aside class="sidebar-nav">
    <nav>
        <?php
            // see assets/scss/components/_sidebar.scss for css that hides everything but the current nav section via wordpress nav classes
            wp_nav_menu( array(
            'menu'              => 'Main Nav',
            'theme_location'    => 'header-menu',
            'depth'             => 3,
            'container'         => 'false',
            'menu_id'        => 'sidebar-nav',        
            ))
        ?>
    </nav>

</aside>