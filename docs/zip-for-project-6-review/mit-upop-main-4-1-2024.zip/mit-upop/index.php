<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package mitupop
 */

get_header();
?>

<section class="hero" style="background-image: url(<?php bloginfo("template_url"); ?>/assets/img/hero.jpg)"></section>
<section id="primary" class="page-intro">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1><?php the_title(); ?></h1>
            </div>
            <div class="col-lg-3 d-none d-lg-block">
                <div class="col-inner">
                    <?php get_sidebar(); ?>
                </div>
            </div>
            <div class="col-lg-9">
                <div class="col-inner">
                    <article>
                        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                        <?php the_content(); ?>
                        <?php endwhile; endif; ?>
                    </article>
                </div>
            </div>
        </div>
    </div>
</section>

<?php get_template_part( 'template-parts/testimonial' ); ?>
<?php get_template_part( 'template-parts/cta-banner' ); ?>
<?php get_footer(); ?>