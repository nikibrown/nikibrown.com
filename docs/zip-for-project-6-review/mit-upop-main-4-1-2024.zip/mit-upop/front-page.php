<?php
/**
 * Front Page
 *
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package mitupop
 */

get_header();
?>

<?php get_template_part('template-parts/home-slider-mobile'); ?>
<?php get_template_part('template-parts/home-slider-desktop'); ?>

<section class="sponsors">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="lead"><?php the_field("section_headline"); ?></h2>
                <?php the_field("section_content"); ?>
            </div>
        </div>
    </div>
</section>

<?php get_template_part( 'template-parts/testimonial' ); ?>

<section class="announcements upop-purple">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <?php $announcement_photo = get_field('announcement_photo'); ?>
                <?php echo wp_get_attachment_image( $announcement_photo, 'full',false, array('class' => 'img-fluid')); ?>
            </div>
            <div class="col-lg-6">
                <div class="text-inner">
                    <h2 class="has-orange-bar">Announcements &amp; Events</h2>

                    <div class="anouncements-content">
                        <?php the_field("announcement_content"); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php if(get_field("show_intro_links")) { ?>
<section class="intro-links">
    <div class="container">
        <div class="row">
            <?php if( have_rows('intro_links') ): ?>
            <?php while( have_rows('intro_links') ): the_row(); ?>
            <div class="col-lg-4">
                <div class="inner-content has-pink-bar">
                    <h2><?php the_sub_field("headline"); ?></h2>
                    <?php the_sub_field("text"); ?>
                    <a href="<?php the_sub_field("button_link"); ?>" class="btn btn-secondary">
                        <?php the_sub_field("button_text"); ?>
                    </a>
                </div>
            </div>
            <?php endwhile; ?>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php } ?>

<?php get_template_part('template-parts/sponsors'); ?>
<?php get_template_part( 'template-parts/cta-banner' ); ?>
<?php get_footer(); ?>